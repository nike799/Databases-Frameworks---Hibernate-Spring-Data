CREATE PROCEDURE usp_get_count_of_books_of_given_author(IN first__name VARCHAR(255), IN last__name VARCHAR(255))
  BEGIN
    SELECT COUNT(*) FROM books b
    JOIN authors a ON b.author_id = a.id
    WHERE a.first_name = first__name AND a.last_name = last__name;
  END;

